<?php
function jltwp_adminify_update_options_data()
{
    // delete_option('_wpadminify', 'folders');
    // delete_option('_wpadminify', 'notification_bar');
    // delete_option('_wpadminify', 'notification_bar');
}
jltwp_adminify_update_options_data();
